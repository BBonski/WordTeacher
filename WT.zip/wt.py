from tkinter import *
from os import system

win = Tk()
win.geometry('640x480')
win.title('WordTeacher')

win_frame = Frame()
win_frame.pack(fill = "both", expand = True)

def menu():
    l = Label(win_frame, text = 'Menu', font = ('Helvetica, 32')) 
    l.place(relx = 0.5, rely = 0.25, anchor = CENTER)

    btn_frame = Frame()
    btn_frame.place(in_ = win_frame, relx = 0.5, rely = 0.75, anchor = CENTER)

    learn_btn = Button(btn_frame,
                       text = 'Nauka',
                       padx = 50, pady = 25,
                       bg = 'white',
                       width = 5,
                       height = 2,
                       command = lambda:[win.destroy()])
    learn_btn.grid(row = 0, column = 0)

    test_btn = Button(btn_frame,
                      text = 'Test',
                      padx = 50, pady = 25,
                      bg = 'white',
                      width = 5,
                      height = 2,
                      command = lambda:[win.destroy(), system("python3 test.py")])
    test_btn.grid(row = 0, column = 1)

    new_btn = Button(btn_frame,
                     text = 'Nowy\nzestaw',
                     padx = 50, pady = 25,
                     bg = '#ffffff',
                     width = 5,
                     height = 2,
                     command = lambda:[win.destroy(), system("python3 newSet.py")])
    new_btn.grid(row = 0, column = 2)

    end_btn = Button(btn_frame,
                     text = 'Koniec\nprogramu',
                     padx = 50, pady = 25,
                     bg = '#ffffff',
                     width = 5,
                     height = 2,
                     command = quit)
    end_btn.grid(row = 0, column = 3)

menu()
win.mainloop()
