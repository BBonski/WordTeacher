from tkinter import *
from os import chdir, system

chdir('data') #enters data directory used to store wordsets

word_count = 0

win = Tk()
win.geometry('640x480')
win.title('WordTeacher - nowy zestaw')

#function handling set creation procecure
def makeSet():
    #added words counter
    count_lbl = Label(text = 'Dodane słowa: 0')
    count_lbl.place(relx = 0.025, rely = 0.025)

    file = open(fname, 'w')

    #main frame consisting of 2 subframes
    main_frame = Frame()
    main_frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

    #first subframe (labels and input fields to write words)
    inp_frame = Frame(main_frame)
    inp_frame.grid(row = 0, column = 0)

    lbl1 = Label(inp_frame, text = 'Słowo w twoim języku:').grid(row = 0, column = 0)

    inpBox1 = Entry(inp_frame, width = 50)
    inpBox1.grid(row = 1, column = 0)

    Label(inp_frame, text = '').grid(row = 2, column = 0) #empty label as a spacing

    lbl2 = Label(inp_frame, text = 'Słowo w języku obcym:').grid(row = 3, column = 0)

    inpBox2 = Entry(inp_frame, width = 50)
    inpBox2.grid(row = 4, column = 0)

    Label(inp_frame, text = '').grid(row = 5, column = 0) #another spacing

    #function saving word to file and preparing for the next one
    def saveWord():
        #writing word to the file
        file.write(inpBox1.get() + '\n' + inpBox2.get() + '\n')

        #clearing inputs
        inpBox1.delete(0, 'end')
        inpBox2.delete(0, 'end')

        #updating word count by cutting out number from label text and replacing label text with text that has bigger number + 1
        count_lbl.config(text = 'Dodane słowa: ' + str(int(count_lbl.cget('text')[14:]) + 1))

    #function saving wordset that also quits the module
    def saveSet():
        file.close()
        win.destroy()
        chdir('..')
        system('python3 wt.py')

    #second subframe (buttons to confirm word or save set)
    btn_frame = Frame(main_frame)
    btn_frame.grid(row = 2, column = 0)

    add_word_btn = Button(btn_frame, text = 'Dodaj', command = saveWord)
    add_word_btn.grid(row = 0, column = 0)
    save_set_btn = Button(btn_frame, text = 'Zapisz zestaw', command = saveSet)
    save_set_btn.grid(row = 0, column = 1)

#function used to create wordset file
def makeFile():
    win_frame = Frame()
    win_frame.pack(fill = "both", expand = True)

    def saveFile():
        global fname
        fname = inpBox.get()
        file = open(fname, 'w')
        file.close()
        win_frame.destroy()
        makeSet()

    lbl = Label(text = 'Podaj nazwę nowego zestawu:').place(in_ = win_frame,
                                                            rely = 0.25,
                                                            relx = 0.5,
                                                            anchor = CENTER)

    inpBox = Entry(width = 50)
    inpBox.place(in_ = win_frame, relx = 0.5, rely = 0.5, anchor = CENTER)

    btn = Button(text = 'OK', command = saveFile).place(in_ = win_frame,
                                                        rely = 0.75,
                                                        relx = 0.5,
                                                        anchor = CENTER)

makeFile()
mainloop()