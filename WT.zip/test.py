from tkinter import *
from os import chdir, listdir, system

chdir('data')

win = Tk()
win.geometry('640x480')
win.title('WordTeacher - test')

#lists instead of plain variables to allow modifying values from functions
score = [0]
tested = [0]
correct = [0]

#function that runs menu back
def menu():
	win.destroy()
	chdir('..')
	system('python3 wt.py')

#function handling screen with score information
def endScreen():
	frame = Frame()
	frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

	lbl = Label(frame, text = 'Twój wynik: ' + str(score[0]) + '%', font = ('Helvetica, 32'))
	lbl.grid(row = 0, column = 0)

	Label(frame, text = '').grid(row = 1, column = 0)

	Button(frame, text = 'OK', command = menu).grid(row = 2, column = 0)

#the "main" function
def test():
	#reading set from file to memory to lists
	file = open(name, 'r')
	native_word = True

	#two lists to store native and foreign words
	n_words = []
	f_words = []

	for ln in file:
		#print(ln)
		if ln != '\n':
			ln = ln[:-1]

			if native_word == True:
				n_words.append(ln)
			else:
				f_words.append(ln)

			native_word = not(native_word)

	print(n_words, 'f', f_words)
	file.close()

	count_lbl = Label(text = 'Sprawdzone słowa: 0')

	main_frame = Frame()
	main_frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

	inp_frame = Frame(main_frame)
	inp_frame.grid(row = 0, column = 0)

	lbl1 = Label(inp_frame, text = 'Słowo w twoim języku:').grid(row = 0, column = 0)
	n_lbl = Label(inp_frame, text = n_words[0])
	n_lbl.grid(row = 1, column = 0)

	Label(inp_frame, text = '').grid(row = 2, column = 0) #empty label as a spacing

	lbl2 = Label(inp_frame, text = 'Słowo w języku obcym:').grid(row = 3, column = 0)

	inpBox = Entry(inp_frame, width = 50)
	inpBox.grid(row = 4, column = 0)

	Label(inp_frame, text = '').grid(row = 5, column = 0) #another spacing

	btn_frame = Frame(main_frame)
	btn_frame.grid(row = 2, column = 0)

	#function that sets next words by removing used words from list
	def nextWord():
		tested[0] += 1
		if inpBox.get() == f_words[0]:
			correct[0] += 1
			#print('dobrze')
		else:
			print('zle')

		#removing tested words from list and setting new view
		if len(n_words)-1 > 0:
			print(len(n_words))
			f_words.pop(0)
			n_words.pop(0)
			n_lbl.config(text = n_words[0])
			inpBox.delete(0, 'end')
		else:
			score[0] = round((correct[0] / tested[0]) * 100) #calculating score in percents
			main_frame.destroy()
			endScreen()

	ok_word_btn = Button(btn_frame, text = 'Następne', command = nextWord)
	ok_word_btn.grid(row = 0, column = 0)

#starting function to select file with wordset
def readFile():
    main_frame = Frame()
    main_frame.place(relx = 0.025, rely = 0.025, relwidth = 0.95, relheight = 0.75)

    Label(main_frame, text = 'Wybierz zestaw\n').pack()
    
    bar = Scrollbar(main_frame, orient = "vertical")
    lst = Listbox(main_frame, yscrollcommand = bar.set, listvariable = StringVar(value = listdir()), selectmode = SINGLE)
    bar.config(command = lst.yview)

    bar.pack(side = "right", fill = "y")
    lst.pack(side = "left", fill = "both", expand = True)

    def getSet():
    	global name
    	name = listdir()[lst.curselection()[0]] #getting the file name from selected item of list
    	main_frame.destroy()                    #curselection method returns tuple with number of item
    	btn.destroy()
    	test()
    	#print(name)

    btn = Button(text = 'OK', command = getSet)
    btn.place(relx = 0.5, rely = 0.85, anchor = CENTER)

readFile()
win.mainloop()