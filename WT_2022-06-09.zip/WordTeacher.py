from tkinter import *
from os import system

win = Tk()
win.geometry('640x480')
interface = dict()

#function handling learn mode
def learn():
    from os import chdir, listdir
    from random import randint

    win.title(interface["learn_win_title"])

    #lists instead of plain variables to allow modifying values from functions
    learned = [0]
    how_many_times = [int(open('learn.cfg').read())]

    #lists to store the words and count of correct answers of each word
    n_words = []
    f_words = []
    answers = []

    #list to store the index of word to learn and previously learned word
    rand_ind = [0, 0]

    chdir('data')

    #function setting random word not allowing to set the same word two times consecutively
    def randomize():
        if len(n_words) > 1:
            while (rand_ind[0] == rand_ind[1]):
                rand_ind[0] = randint(0, len(n_words)-1)
            rand_ind[1] = rand_ind[0]
        else:
            rand_ind[0] = randint(0, len(n_words)-1)

    #function handling screen with score information
    def endScreen():
        frame = Frame(bg = interface["main_bg"])
        frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

        Label(frame, text = interface["learned_words_lbl"] + str(learned[0]), font = ('Helvetica, 32'), fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 0, column = 0)
        Label(frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 1, column = 0) #spacing

        #function that runs menu back
        def end():
            frame.destroy()
            chdir('..')
            main()

        Button(frame, text = interface["ok_btn_icon"] + ' OK', fg = interface["btn_fg"], bg = interface["btn_bg"], command = end).grid(row = 2, column = 0)

    #the "main" function
    def _learn():
        #reading set from file to memory to lists
        file = open(name, 'r')
        native_word = True

        for ln in file:
            if ln != '\n':
                ln = ln[:-1]

                if native_word == True:
                    n_words.append(ln)
                else:
                    f_words.append(ln)
                    answers.append(0)

                native_word = not(native_word)

        file.close()
        
        randomize()

        count_lbl = Label(text = interface["learned_words_lbl"] + '0/' + str(len(n_words)) + ' (0%)', fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        count_lbl.place(relx = 0.025, rely = 0.025)

        main_frame = Frame(bg = interface["main_bg"])
        main_frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

        inp_frame = Frame(main_frame, bg = interface["main_bg"])
        inp_frame.grid(row = 0, column = 0)

        lbl1 = Label(inp_frame, text = interface["nat_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 0, column = 0)
        nword_lbl = Label(inp_frame, text = n_words[rand_ind[0]], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        nword_lbl.grid(row = 1, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 2, column = 0) #empty label as a spacing

        lbl2 = Label(inp_frame, text = interface["for_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 3, column = 0)

        inpBox = Entry(inp_frame, width = 50)
        inpBox.grid(row = 4, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 5, column = 0) #another spacing

        #labels showing if answer was correct and what was the correct one if the typed answer was wrong
        if_correct_lbl1 = Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        if_correct_lbl1.grid(row = 6, column = 0)
        if_correct_lbl2 = Label(inp_frame, text = '', font='bold', fg = '#ff0000', bg = interface["lbl_bg"])
        if_correct_lbl2.grid(row = 7, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 8, column = 0) #another spacing

        btn_frame = Frame(main_frame, bg = interface["main_bg"])
        btn_frame.grid(row = 1, column = 0)

        def cancelLearn():
            main_frame.destroy()
            btn_frame.destroy()
            count_lbl.destroy()
            chdir('..')
            main()

        #function that sets next words
        def nextWord():
            #clearing the information about correctnes of previous answer
            if_correct_lbl1.config(text = '')
            if_correct_lbl2.config(text = '')

            #setting next word
            if len(n_words) > 0:
                randomize()
                #print('wylosoway indeks:', rand_ind[0])
                nword_lbl.config(text = n_words[rand_ind[0]])
                inpBox.delete(0, 'end')
                confirm_btn.config(text = interface["check_btn_icon"] + ' ' + interface["confirm_btn_check"], command = checkWord) #changing the button function again
            else:
                #count_lbl.config(text = '')
                count_lbl.destroy()
                main_frame.destroy()
                endScreen()

        def checkWord():
            #print('sprawdzane:', n_words[rand_ind[0]], f_words[rand_ind[0]], 'elem w listach:', len(n_words), len(f_words), len(answers))
            if inpBox.get() == f_words[rand_ind[0]]:
                if_correct_lbl1.config(text = interface["if_correct_lbl_good"])
                if_correct_lbl1.config(fg = '#00ff00')

                #checking if correct answer has been typed enough times, deleting word from lists and incrementing learned words count if so
                if answers[rand_ind[0]]+1 == how_many_times[0]: 
                    answers.pop(rand_ind[0])
                    n_words.pop(rand_ind[0])
                    f_words.pop(rand_ind[0])
                    learned[0] += 1
                else:
                    answers[rand_ind[0]] += 1

                count_lbl.config(text = interface["learned_words_lbl"] + str(learned[0]) + '/' + str(learned[0]+len(n_words)) + ' ' +
                                 '(' + str(round(learned[0]/(learned[0]+len(n_words))*100)) + '%' + ')')
                #number of all words = words already learned + words remain, learned words percentage = learned/all * 100
            else:
                if_correct_lbl1.config(text = interface["if_correct_lbl_bad"])
                if_correct_lbl1.config(fg = '#ff0000')
                if_correct_lbl2.config(text = f_words[rand_ind[0]])

                answers[rand_ind[0]] = 0 #reseting count of correct answers because correct answers must be consecutive

            #updating the variables
            if len(n_words) > 0:
                confirm_btn.config(text = interface["next_word_btn_icon"] + ' ' + interface["confirm_btn_next"], command = nextWord) #changing the button function
            else:
                confirm_btn.config(text = interface["summary_btn_icon"] + ' ' + interface["confirm_btn_end"], command = nextWord)

        confirm_btn = Button(btn_frame, text = interface["check_btn_icon"] + ' ' + interface["confirm_btn_check"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = checkWord)
        confirm_btn.grid(row = 0, column = 0)
        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancelLearn)
        cancel_btn.grid(row = 0, column = 1)

    #starting function to select file with wordset
    def readFile():
        main_frame = Frame(bg = interface["main_bg"])
        main_frame.place(relx = 0.025, rely = 0.025, relwidth = 0.95, relheight = 0.75)

        Label(main_frame, text = interface["select_set_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).pack()
        
        bar = Scrollbar(main_frame, orient = "vertical")
        lst = Listbox(main_frame, yscrollcommand = bar.set, listvariable = StringVar(value = listdir()), selectmode = SINGLE)
        bar.config(command = lst.yview)

        bar.pack(side = "right", fill = "y")
        lst.pack(side = "left", fill = "both", expand = True)

        btn_frame = Frame(bg = interface["main_bg"])
        btn_frame.place(relx = 0.5, rely = 0.85, anchor = CENTER)

        def getSet():
            global name
            name = listdir()[lst.curselection()[0]] #getting the file name from selected item of list
            main_frame.destroy()                    #curselection method returns tuple with number of item
            btn_frame.destroy()
            _learn()

        def cancelLearn():
            main_frame.destroy()
            btn_frame.destroy()
            chdir('..')
            main()

        ok_btn = Button(btn_frame, text = interface["ok_btn_icon"] + " OK", fg = interface["btn_fg"], bg = interface["btn_bg"], command = getSet)
        ok_btn.grid(row = 0, column = 0)

        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancelLearn)
        cancel_btn.grid(row = 0, column = 1)

    readFile()

#function handling test mode
def test():
    from os import chdir, listdir
    
    win.title(interface["test_win_title"])
    chdir('data')

    #lists instead of plain variables to allow modifying values from functions
    score = [0]
    tested = [0]
    correct = [0]
    _all = ['']

    #function handling screen with score information
    def endScreen():
        #function that runs menu back
        def end():
            chdir('..')
            frame.destroy()
            main()

        frame = Frame(bg = interface["main_bg"])
        frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

        Label(frame, text = interface["good_answers_lbl"] + str(correct[0]), font = ('Helvetica, 16'), fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 0, column = 0)
        Label(frame, text = interface["bad_answers_lbl"] + str(tested[0] - correct[0]), font = ('Helvetica, 16'), fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 1, column = 0)
        Label(frame, text = interface["final_score_lbl"] + str(score[0]) + '%', font = ('Helvetica, 32'), fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 2, column = 0)
        Label(frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 3, column = 0) #spacing
        Button(frame, text = interface["ok_btn_icon"] + ' OK', fg = interface["btn_fg"], bg = interface["btn_bg"], command = end).grid(row = 4, column = 0)

    #the "main" function
    def _test():
        #reading set from file to memory to lists
        file = open(name, 'r')
        native_word = True

        #two lists to store native and foreign words
        n_words = []
        f_words = []

        for ln in file:
            if ln != '\n':
                ln = ln[:-1]

                if native_word == True:
                    n_words.append(ln)
                else:
                    f_words.append(ln)

                native_word = not(native_word)

        file.close()

        _all[0] = str(len(n_words)) #number of all words to be tested

        count_lbl = Label(text = interface["count_lbl_checked"] + '0/' + _all[0], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        count_lbl.place(relx = 0.025, rely = 0.025)

        main_frame = Frame(bg = interface["main_bg"])
        main_frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)

        inp_frame = Frame(main_frame, bg = interface["main_bg"])
        inp_frame.grid(row = 0, column = 0)

        lbl1 = Label(inp_frame, text = interface["nat_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 0, column = 0)
        nword_lbl = Label(inp_frame, text = n_words[0], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        nword_lbl.grid(row = 1, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 2, column = 0) #empty label as a spacing

        lbl2 = Label(inp_frame, text = interface["for_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 3, column = 0)

        inpBox = Entry(inp_frame, width = 50)
        inpBox.grid(row = 4, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 5, column = 0) #another spacing

        if_correct_lbl1 = Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        if_correct_lbl1.grid(row = 6, column = 0)
        if_correct_lbl2 = Label(inp_frame, text = '', font='bold', fg = '#ff0000', bg = interface["lbl_bg"])
        if_correct_lbl2.grid(row = 7, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 8, column = 0) #another spacing

        btn_frame = Frame(main_frame, bg = interface["main_bg"])
        btn_frame.grid(row = 1, column = 0)

        def cancelTest():
            main_frame.destroy()
            btn_frame.destroy()
            count_lbl.destroy()
            chdir('..')
            main()

        #function that sets next words by removing used words from list
        def nextWord():
            #clearing the information about correctnes of previous answer
            if_correct_lbl1.config(text = '')
            if_correct_lbl2.config(text = '')

            #removing tested words from list and setting new view
            if len(n_words)-1 > 0:
                f_words.pop(0)
                n_words.pop(0)
                nword_lbl.config(text = n_words[0])
                inpBox.delete(0, 'end')
                confirm_btn.config(text = interface["check_btn_icon"] + ' ' + interface["confirm_btn_check"], command = checkWord) #changing the button function again
            else:
                count_lbl.config(text = '')
                main_frame.destroy()
                endScreen()

        def checkWord():
            if inpBox.get() == f_words[0]:
                correct[0] += 1
                if_correct_lbl1.config(text = interface["if_correct_lbl_good"])
                if_correct_lbl1.config(fg = '#00ff00')
            else:
                if_correct_lbl1.config(text = interface["if_correct_lbl_bad"])
                if_correct_lbl1.config(fg = '#ff0000')
                if_correct_lbl2.config(text = f_words[0])

            #updating the variables
            tested[0] += 1
            score[0] = round((correct[0] / tested[0]) * 100) #calculating the score in percents

            count_lbl.config(text = interface["count_lbl_checked"] + str(tested[0]) + '/' + _all[0] + '    ' +
                                    interface["count_lbl_correctness"] + str(score[0]) + '%')

            if len(n_words)-1 > 0:
                confirm_btn.config(text = interface["next_word_btn_icon"] + ' ' + interface["confirm_btn_next"], command = nextWord) #changing the button function
            else:
                confirm_btn.config(text = interface["summary_btn_icon"] + ' ' + interface["confirm_btn_end"], command = nextWord)

        confirm_btn = Button(btn_frame, text = interface["check_btn_icon"] + ' ' + interface["confirm_btn_check"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = checkWord)
        confirm_btn.grid(row = 0, column = 0)
        cancel_btn = Button(btn_frame, text =  interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancelTest)
        cancel_btn.grid(row = 0, column = 1)

    #starting function to select file with wordset
    def readFile():
        main_frame = Frame(bg = interface["main_bg"])
        main_frame.place(relx = 0.025, rely = 0.025, relwidth = 0.95, relheight = 0.75)

        Label(main_frame, text = interface["select_set_lbl"] + '\n', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).pack()
        
        bar = Scrollbar(main_frame, orient = "vertical")
        lst = Listbox(main_frame, yscrollcommand = bar.set, listvariable = StringVar(value = listdir()), selectmode = SINGLE)
        bar.config(command = lst.yview)

        bar.pack(side = "right", fill = "y")
        lst.pack(side = "left", fill = "both", expand = True)

        btn_frame = Frame(bg = interface["main_bg"])
        btn_frame.place(relx = 0.5, rely = 0.85, anchor = CENTER)

        def getSet():
            global name
            name = listdir()[lst.curselection()[0]] #getting the file name from selected item of list
            main_frame.destroy()                    #curselection method returns tuple with number of item
            btn_frame.destroy()
            _test()

        def cancelTest():
            main_frame.destroy()
            btn_frame.destroy()
            chdir('..')
            main()

        ok_btn = Button(btn_frame, text = interface["ok_btn_icon"] + ' OK', fg = interface["btn_fg"], bg = interface["btn_bg"], command = getSet)
        ok_btn.grid(row = 0, column = 0)

        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancelTest)
        cancel_btn.grid(row = 0, column = 1)

    readFile()

#function handling set overview
def overview():
    from os import chdir, listdir

    chdir('data')

    def showWords():
        file = open(name, "r")
        string = ""
        line_count = 0

        for line in file:
            string += line + (line_count % 2) * '\n' #adding additional endline as a spacing after every words pair
            line_count += 1

        file.close()

        #main frame
        main_frame = Frame(bg = interface["main_bg"])
        main_frame.pack(fill = "both", expand = True)

        #sub frame with label and text box
        sub_frame = Frame(main_frame, padx = 10, bg = interface["main_bg"])
        sub_frame.place(relx = 0, rely = 0, relwidth = 1, relheight = 0.85)

        count_lbl = Label(sub_frame, text = interface["count_lbl"] + str(line_count//2), pady = 10, fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        count_lbl.pack(anchor = NW)

        content_txt = Text(sub_frame)
        content_txt.insert(1.0, string)
        content_txt.configure(state = 'disabled')
        content_txt.pack(fill = "both", expand = True)

        def menu():
            chdir('..')
            main_frame.destroy()
            main()

        ok_btn = Button(main_frame, text = interface["ok_btn_icon"] + " OK", fg = interface["btn_fg"], bg = interface["btn_bg"], command = menu)
        ok_btn.place(relx = 0.5, rely = 0.86, anchor = N)

    #starting function to select file with wordset
    def readFile():
        main_frame = Frame(bg = interface["main_bg"])
        main_frame.place(relx = 0.025, rely = 0.025, relwidth = 0.95, relheight = 0.75)

        Label(main_frame, text = interface["select_set_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).pack()
        Label(main_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).pack()
        
        bar = Scrollbar(main_frame, orient = "vertical")
        lst = Listbox(main_frame, yscrollcommand = bar.set, listvariable = StringVar(value = listdir()), selectmode = SINGLE)
        bar.config(command = lst.yview)

        bar.pack(side = "right", fill = "y")
        lst.pack(side = "left", fill = "both", expand = True)

        btn_frame = Frame(bg = interface["main_bg"])
        btn_frame.place(relx = 0.5, rely = 0.85, anchor = CENTER)

        def getSet():
            global name
            name = listdir()[lst.curselection()[0]] #getting the file name from selected item of list
            main_frame.destroy()                    #curselection method returns tuple with number of item
            btn_frame.destroy()
            showWords()

        def cancel():
            main_frame.destroy()
            btn_frame.destroy()
            chdir('..')
            main()

        ok_btn = Button(btn_frame, text = interface["ok_btn_icon"] + ' OK', fg = interface["btn_fg"], bg = interface["btn_bg"], command = getSet)
        ok_btn.grid(row = 0, column = 0)

        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancel)
        cancel_btn.grid(row = 0, column = 1)

    readFile()

#function handling new set creator
def newSet():
    from os import chdir, remove
    chdir('data') #enters data directory used to store wordsets

    word_count = [0]

    win.title(interface["new_set_win_title"])

    #function handling set creation procecure
    def makeSet():
        file = open(fname, 'w')

        main_frame = Frame(bg = interface["main_bg"])
        main_frame.pack(fill = 'both', expand = True)

        #main frame consisting of 2 subframes
        main_subframe = Frame(bg = interface["main_bg"])
        main_subframe.place(in_ = main_frame, relx = 0.5, rely = 0.5, anchor = CENTER)

        #added words counter
        count_lbl = Label(text = interface["added_words_lbl"]+ ' 0', fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        count_lbl.place(in_ = main_frame, relx = 0.025, rely = 0.025)

        #first subframe (labels and input fields to write words)
        inp_frame = Frame(main_subframe, bg = interface["main_bg"])
        inp_frame.grid(row = 0, column = 0)

        lbl1 = Label(inp_frame, text = interface["nat_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 0, column = 0)

        inpBox1 = Entry(inp_frame, width = 50)
        inpBox1.grid(row = 1, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 2, column = 0) #empty label as a spacing

        lbl2 = Label(inp_frame, text = interface["for_word_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 3, column = 0)

        inpBox2 = Entry(inp_frame, width = 50)
        inpBox2.grid(row = 4, column = 0)

        Label(inp_frame, text = '', fg = interface["lbl_fg"], bg = interface["lbl_bg"]).grid(row = 5, column = 0) #another spacing

        #function saving word to file and preparing for the next one
        def saveWord():
            #writing word to the file
            file.write(inpBox1.get() + '\n' + inpBox2.get() + '\n')

            #clearing inputs
            inpBox1.delete(0, 'end')
            inpBox2.delete(0, 'end')

            #updating word count by cutting out number from label text and replacing label text with text that has bigger number + 1
            word_count[0] += 1
            count_lbl.config(text = interface["added_words_lbl"] + str(word_count[0]))

        #function saving wordset that also quits the module
        def saveSet():
            file.close()
            chdir('..')
            main_frame.destroy()
            main()

        def discardSet():
            file.close()
            remove(fname)
            chdir('..')
            main_frame.destroy()
            main()

        #second subframe (buttons to confirm word or save set)
        btn_frame = Frame(main_subframe, bg = interface["main_bg"])
        btn_frame.grid(row = 2, column = 0)

        add_word_btn = Button(btn_frame, text = interface["add_word_btn_icon"] + ' ' + interface["add_word_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = saveWord)
        add_word_btn.grid(row = 0, column = 0)
        save_set_btn = Button(btn_frame, text = interface["save_set_btn_icon"] + ' ' + interface["save_set_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = saveSet)
        save_set_btn.grid(row = 0, column = 1)
        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = discardSet)
        cancel_btn.grid(row = 0, column = 2)

    #function used to create wordset file
    def makeFile():
        main_frame = Frame(bg = interface["main_bg"])
        main_frame.pack(fill = "both", expand = True)

        def saveFile():
            global fname
            fname = inpBox.get()
            file = open(fname, 'w')
            file.close()
            main_frame.destroy()
            makeSet()

        def cancelCreation():
            main_frame.destroy()
            chdir('..')
            main()

        new_set_name_lbl = Label(text = interface["new_set_name_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
        new_set_name_lbl.place(in_ = main_frame, rely = 0.25, relx = 0.5, anchor = CENTER)

        inpBox = Entry(width = 50)
        inpBox.place(in_ = main_frame, relx = 0.5, rely = 0.5, anchor = CENTER)

        btn_frame = Frame(bg = interface["main_bg"])
        btn_frame.place(in_ = main_frame, rely = 0.75, relx = 0.5, anchor = CENTER)

        ok_btn = Button(btn_frame, text = interface["ok_btn_icon"] + ' OK', fg = interface["btn_fg"], bg = interface["btn_bg"], command = saveFile)
        ok_btn.grid(row = 0, column = 0)

        cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], fg = interface["btn_fg"], bg = interface["btn_bg"], command = cancelCreation)
        cancel_btn.grid(row = 0, column = 1)

    makeFile()

#function handling settings screen
def settings():
    from os import chdir, listdir

    settings_win_frame = Frame(bg = interface["main_bg"])
    settings_win_frame.pack(fill = "both", expand = True)

    win.title(interface["settings_win_title"])
    
    how_many_times = [open('learn.cfg').read()]
    themes_names = []
    themes_files = []
    langs_names = []
    langs_codes = []

    for ln in open('langs.dict'):
        ln = ln[:-1]
        if ln != '' and ln[0] != '#': #ignoring comments and empty lines
            langs_names.append(ln.split('=')[0])
            langs_codes.append(ln.split('=')[1])

    #reading themes
    chdir('themes')
    for i in listdir():
        themes_files.append(i.split('.')[0])
        themes_names.append(interface[i.split('.')[0]])
    chdir('..')

    #label
    settings_lbl = Label(settings_win_frame, text = interface["settings_lbl"], font = ('Helvetica, 32'), pady = 50, fg = interface["lbl_fg"], bg = interface["lbl_bg"]) 
    settings_lbl.pack(anchor = CENTER)

    #sub-frame with all settings
    settings_frame = Frame(settings_win_frame, padx = 10, bg = interface["main_bg"])
    settings_frame.pack(fill = 'x')

    language_lbl = Label(settings_frame, text = interface["lang_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
    language_lbl.pack(anchor = NW)

    lang_lst = Listbox(settings_frame, selectmode = SINGLE, listvariable = StringVar(value = langs_names), height = 5, exportselection = False)
    lang_lst.pack(anchor = NW, fill = 'x')

    theme_lbl = Label(settings_frame, text = interface["theme_lbl"], fg = interface["lbl_fg"], bg = interface["lbl_bg"])
    theme_lbl.pack(anchor = NW)

    theme_lst = Listbox(settings_frame, selectmode = SINGLE, listvariable = StringVar(value = themes_names), height = 5, exportselection = False)
    theme_lst.pack(anchor = NW, fill = 'x')

    #sub-sub-frame for learn intensity configuration
    learn_frame = Frame(settings_frame, bg = interface["main_bg"])
    learn_frame.pack()

    learn_cfg_lbl = Label(settings_frame, text = interface["learn_cfg_lbl"] + ' (' + interface["learn_cfg_lbl_curr"] + str(how_many_times[0]) + ', ' + interface["learn_cfg_lbl_def"] + ')', fg = interface["lbl_fg"], bg = interface["lbl_bg"])
    learn_cfg_lbl.pack(side = LEFT, anchor = S)

    learn_cfg_inp = Entry(settings_frame, width = 2)
    learn_cfg_inp.pack(side = RIGHT, anchor = N)

    #sub-frame with buttons
    btn_frame = Frame(bg = interface["main_bg"])
    btn_frame.place(in_ = settings_win_frame, relx = 0.5, rely = 0.875, anchor = N)

    def end():
        settings_win_frame.destroy()
        main()

    def applySettings():
        #applying language settings (if were changed)
        if len(lang_lst.curselection()) != 0:
            cfg_file = open('current_lang.cfg', 'w')
            cfg_file.write(langs_codes[lang_lst.curselection()[0]])
            cfg_file.close()
            interface.clear() #clearing out translations so they will be read when menu is launched again

        #applying theme settings (if were changed)
        if len(theme_lst.curselection()) != 0:
            cfg_file = open('current_theme.cfg', 'w')
            cfg_file.write(themes_files[theme_lst.curselection()[0]])
            cfg_file.close()
            interface.clear()
        
        #applying learn intensity settings (if were changed)
        if learn_cfg_inp.get() != '':
            cfg_file = open('learn.cfg', 'w')
            cfg_file.write(learn_cfg_inp.get())
            cfg_file.close()

        end()

    apply_btn = Button(btn_frame, text = interface["apply_btn_icon"] + ' ' + interface["apply_btn"], bg = interface["btn_bg"], fg = interface["btn_fg"], command = applySettings)
    apply_btn.pack(side = LEFT)
    cancel_btn = Button(btn_frame, text = interface["cancel_btn_icon"] + ' ' + interface["cancel_btn"], bg = interface["btn_bg"], fg = interface["btn_fg"], command = end)
    cancel_btn.pack(side = LEFT)

#main function hadling main menu and app initialization
def main():
    from os import chdir

    #importing user interface translations and theme based on current configuration
    if len(interface) == 0:
        for ln in open(open('current_lang.cfg').read() + '.dict'):    #reading translations
            ln = ln[:-1]
            if ln != '' and ln[0] != '#':                             #ignoring comments and empty lines
                interface.update({ln.split('=')[0]:ln.split('=')[1]})

        #reading theme
        curr_theme = open('current_theme.cfg').read()
        chdir('themes')
        for ln in open(curr_theme + '.theme'):
            ln = ln[:-1]
            if ln != '' and ln[0] != '#':
                interface.update({ln.split('=')[0]:ln.split('=')[1]})
        chdir('..')

    menu_win_frame = Frame(bg = interface["main_bg"])
    menu_win_frame.pack(fill = "both", expand = True)

    win.title(interface["menu_win_title"])
    win.configure(bg = interface["main_bg"])

    menu_lbl = Label(menu_win_frame, text = interface["menu_lbl"], font = ('Helvetica, 32'), pady = 50, fg = interface["lbl_fg"], bg = interface["lbl_bg"]) 
    menu_lbl.pack(anchor = CENTER)

    btn_frame = Frame(bg = interface["main_bg"])
    btn_frame.place(in_ = menu_win_frame, relx = 0.5, rely = 0.75, anchor = CENTER)

    learn_btn = Button(btn_frame,
                       text = interface["learn_btn_icon"] + '\n\n' + interface["learn_btn"],
                       padx = 50, pady = 25,
                       width = 5, height = 2,
                       fg = interface["btn_fg"], bg = interface["btn_bg"],
                       command = lambda:[menu_win_frame.destroy(), learn()])
    learn_btn.grid(row = 0, column = 0)

    test_btn = Button(btn_frame,
                      text = interface["test_btn_icon"] + '\n\n' + interface["test_btn"],
                      padx = 50, pady = 25,
                      width = 5, height = 2,
                      fg = interface["btn_fg"], bg = interface["btn_bg"],
                      command = lambda:[menu_win_frame.destroy(), test()])
    test_btn.grid(row = 0, column = 1)

    overview_btn = Button(btn_frame,
                          text = interface["overview_btn_icon"] + '\n\n' + interface["overview_btn"],
                          padx = 50, pady = 25,
                          width = 5, height = 2,
                          fg = interface["btn_fg"], bg = interface["btn_bg"],
                          command = lambda:[menu_win_frame.destroy(), overview()])
    overview_btn.grid(row = 0, column = 2)

    new_btn = Button(btn_frame,
                     text = interface["new_set_btn_icon"] + '\n\n' + interface["new_set_btn"],
                     padx = 50, pady = 25,
                     width = 5, height = 2,
                     fg = interface["btn_fg"], bg = interface["btn_bg"],
                     command = lambda:[menu_win_frame.destroy(), newSet()])
    new_btn.grid(row = 1, column = 0)

    settings_btn = Button(btn_frame,
                          text = interface["settings_btn_icon"] + '\n\n' + interface["settings_btn"],
                          padx = 50, pady = 25,
                          width = 5, height = 2,
                          fg = interface["btn_fg"], bg = interface["btn_bg"],
                          command = lambda:[menu_win_frame.destroy(), settings()])
    settings_btn.grid(row = 1, column = 1)

    end_btn = Button(btn_frame,
                     text = interface["exit_btn_icon"] + '\n\n' + interface["end_btn"],
                     padx = 50, pady = 25,
                     width = 5, height = 2,
                     fg = interface["btn_fg"], bg = interface["btn_bg"],
                     command = quit)
    end_btn.grid(row = 1, column = 2)

if __name__ == '__main__':
    main()

win.mainloop()